# BlackWillow — Botanica export for Godot 4

Drop this folder anywhere inside your Godot project and instance **BlackWillow.tscn**.

| LOD | Triangles | Vertices | Visible |
|-----|-----------|----------|---------|
| LOD0 | 2,816 | 3,351 | 0–22 m |
| LOD1 | 1,412 | 1,783 | 22–55 m |
| LOD2 | 406 | 672 | 55–141 m |
| LOD3 (billboard, 8×8 views) | 2 | 4 | 141–∞ m |

## Contents

- `BlackWillow.gltf` / `.bin` — meshes for all LODs plus `Trunk-colonly`
  (Godot turns it into a StaticBody3D trunk collider on import).
- `BlackWillow.tscn` — inherited scene: assigns the Botanica shader materials and sets
  per-LOD visibility ranges (hard switch, no margins). Godot's `Self` fade mode
  blends through transparency, which causes sorting artefacts on foliage, so it is left off.
- `LOD3_Impostor` — billboard for the far range: a 2×2 QuadMesh with
  `botanica_impostor.gdshader`, which turns it toward the camera (or the light, for shadows)
  and blends the four nearest of the views baked into `textures/*_impostor_albedo/normal.png`
  (hemi-octahedral atlas, object-space normals so it is lit like the mesh). It casts shadows but
  does not receive them; `custom_aabb` covers the tree because the shader places the vertices.
- `materials/*.tres` — ShaderMaterials (bark, foliage, impostor).
- `shaders/` — `botanica_foliage.gdshader` (alpha-tested, double-sided, translucency via
  BACKLIGHT, mip-aware alpha, wind) and `botanica_bark.gdshader`.
- `textures/` — albedo (sRGB, alpha), normal (OpenGL/+Y), ORM (AO/Roughness/–),
  translucency. `.import` presets mark normal maps and enable mipmaps.
- `BlackWillow.botanica.json` — source project; open it in Botanica to keep editing.

## Vertex data

| Channel | Meaning |
|---------|---------|
| `COLOR.rgb` | baked ambient occlusion × per-leaf tint (also used by StandardMaterial3D) |
| `UV2.x` | branch flexibility 0 (trunk) → 1 (outer twigs) |
| `UV2.y` | leaf flutter weight 0 (stem) → 1 (leaf tip) |

## Wind

Each material exposes `wind_strength`, `wind_direction`, `wind_speed` and `tree_height`
(preset to 10.08 m). Trunk bend is derived from vertex height, branch sway
from `UV2.x`, leaf flutter from `UV2.y`; the instance position offsets the phase so a
forest does not move in sync. To drive all trees together, turn the wind uniforms into
`global uniform`s in the two shaders.
