// Botanica impostor shader (Godot 4)
// Camera-facing billboard over a hemi-octahedral atlas of baked views, lit with baked normals.
// Casts shadows but does not receive them: in the shadow pass the quad turns toward the light,
// so the visible quad would be cut by its own shadow along a line through the tree center.
// Interior darkening comes from the AO baked into the atlas instead.
shader_type spatial;
render_mode cull_disabled, depth_draw_opaque, diffuse_burley, specular_schlick_ggx, shadows_disabled;

uniform sampler2D albedo_atlas : source_color, filter_linear_mipmap, repeat_disable;
uniform sampler2D normal_atlas : hint_default_white, filter_linear_mipmap, repeat_disable;
uniform float frames = 8.0;
uniform vec3 center = vec3(0.0, 5.0, 0.0);
uniform float radius = 5.0;
uniform float alpha_cutoff : hint_range(0.0, 1.0) = 0.4;
uniform float alpha_mip_boost : hint_range(0.0, 1.0) = 0.25;
uniform float roughness : hint_range(0.0, 1.0) = 0.85;
uniform float specular_amount : hint_range(0.0, 1.0) = 0.3;
uniform vec3 subsurface_color : source_color = vec3(0.66, 0.77, 0.24);
uniform float translucency : hint_range(0.0, 4.0) = 1.0;

varying vec4 imp_a;
varying vec4 imp_b;
varying vec4 imp_c;
varying vec4 imp_d;
varying vec4 imp_w;

vec2 imp_encode(vec3 v) {
	v /= abs(v.x) + abs(v.y) + abs(v.z);
	return vec2(v.x + v.z, v.x - v.z);
}

vec3 imp_decode(vec2 e) {
	vec3 v = vec3((e.x + e.y) * 0.5, 0.0, (e.x - e.y) * 0.5);
	v.y = 1.0 - abs(v.x) - abs(v.z);
	return normalize(v);
}

void imp_basis(vec3 d, out vec3 r, out vec3 u) {
	vec3 up0 = abs(d.y) > 0.999 ? vec3(0.0, 0.0, -1.0) : vec3(0.0, 1.0, 0.0);
	r = normalize(cross(up0, d));
	u = cross(d, r);
}

// atlas uv (xy) and tile-local uv (zw) where the view ray through this vertex meets the frame plane
vec4 imp_frame_uv(vec2 cell, vec3 o, vec3 dir) {
	vec3 D = imp_decode((cell + 0.5) / frames * 2.0 - 1.0);
	vec3 r;
	vec3 u;
	imp_basis(D, r, u);
	vec3 L = o + dir * (dot(center - o, D) / dot(dir, D)) - center;
	vec2 local = vec2(dot(L, r), -dot(L, u)) / (2.0 * radius) + 0.5;
	return vec4((cell + local) / frames, local);
}

void vertex() {
	mat4 inv_model = inverse(MODEL_MATRIX);
	bool ortho = PROJECTION_MATRIX[3][3] == 1.0;
	vec3 cam = (inv_model * vec4(INV_VIEW_MATRIX[3].xyz, 1.0)).xyz;
	vec3 V = ortho ? normalize((inv_model * vec4(INV_VIEW_MATRIX[2].xyz, 0.0)).xyz) : normalize(cam - center);
	vec3 r;
	vec3 u;
	imp_basis(V, r, u);
	vec3 P = center + (r * VERTEX.x + u * VERTEX.y) * radius;
	vec3 o = ortho ? P + V * radius * 4.0 : cam;
	vec3 dir = ortho ? -V : P - cam;

	vec3 vh = vec3(V.x, max(V.y, 0.0), V.z);
	vh = dot(vh, vh) < 1e-6 ? vec3(0.0, 0.0, 1.0) : normalize(vh);
	vec2 g = (imp_encode(vh) * 0.5 + 0.5) * frames - 0.5;
	vec2 c0 = clamp(floor(g), vec2(0.0), vec2(frames - 1.0));
	vec2 f = clamp(g - c0, 0.0, 1.0);
	vec2 c1 = min(c0 + 1.0, vec2(frames - 1.0));
	imp_a = imp_frame_uv(c0, o, dir);
	imp_b = imp_frame_uv(vec2(c1.x, c0.y), o, dir);
	imp_c = imp_frame_uv(vec2(c0.x, c1.y), o, dir);
	imp_d = imp_frame_uv(c1, o, dir);
	imp_w = vec4((1.0 - f.x) * (1.0 - f.y), f.x * (1.0 - f.y), (1.0 - f.x) * f.y, f.x * f.y);

	VERTEX = P;
	NORMAL = V;
}

void imp_accum(vec4 fr, float w, inout vec4 col, inout vec4 nrm) {
	if (w <= 0.0 || any(lessThan(fr.zw, vec2(0.0))) || any(greaterThan(fr.zw, vec2(1.0)))) {
		return;
	}
	vec4 a = texture(albedo_atlas, fr.xy);
	float aw = a.a * w;
	col += vec4(a.rgb * aw, aw);
	nrm += texture(normal_atlas, fr.xy) * aw;
}

void fragment() {
	vec4 col = vec4(0.0);
	vec4 nrm = vec4(0.0);
	imp_accum(imp_a, imp_w.x, col, nrm);
	imp_accum(imp_b, imp_w.y, col, nrm);
	imp_accum(imp_c, imp_w.z, col, nrm);
	imp_accum(imp_d, imp_w.w, col, nrm);
	float cov = max(col.a, 1e-4);

	vec2 ts = vec2(textureSize(albedo_atlas, 0));
	vec2 dx = dFdx(imp_a.xy * ts);
	vec2 dy = dFdy(imp_a.xy * ts);
	float lod = max(0.0, 0.5 * log2(max(dot(dx, dx), dot(dy, dy))));
	ALBEDO = col.rgb / cov;
	ALPHA = col.a * (1.0 + lod * alpha_mip_boost);
	ALPHA_SCISSOR_THRESHOLD = alpha_cutoff;
	ALPHA_ANTIALIASING_EDGE = 0.3;

	vec3 n = normalize(nrm.rgb / cov * 2.0 - 1.0);
	NORMAL = normalize((VIEW_MATRIX * (MODEL_MATRIX * vec4(n, 0.0))).xyz);
	ROUGHNESS = roughness;
	METALLIC = 0.0;
	SPECULAR = specular_amount;
	BACKLIGHT = mix(vec3(1.0), sqrt(subsurface_color), 0.8) * 1.45 * (nrm.a / cov) * translucency;
}
